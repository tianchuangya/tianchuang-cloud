using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

namespace PaviseApp
{
    internal sealed class CoreMatrix : Control
    {
        private sealed class Cell
        {
            public int Cpu;

            public Rectangle Rect;

            public bool Sibling;
        }

        private sealed class Group
        {
            public int Index;

            public ulong Mask;

            public Rectangle Rect;

            public readonly List<Cell> Cells = new List<Cell>();
        }

        private sealed class Band
        {
            public string Title;

            public string Meta;

            public int TitleY;

            public readonly List<Group> Groups = new List<Group>();
        }

        internal enum HeadTag
        {
            None,
            Exclusive,
            Primary,
            Cache,
            Smt
        }

        private const int CellW = 30;

        private const int CellH = 30;

        private const int GroupPad = 3;

        private const int GroupHead = 15;

        private const int GroupGap = 7;

        private const int RowGap = 7;

        private const int BandHead = 26;

        private const int BandGap = 16;

        private readonly List<Band> bands = new List<Band>();

        private ulong selected;

        private ulong allMask;

        private ulong cacheHeavy;

        private int laidOutFor;

        private readonly Motion[] cellOn = new Motion[64];

        public string PrimaryTag;

        public bool MarkExclusive = true;

        public bool ShowCoreTypeStatus = true;

        private bool editable;

        private int focusCpu;

        private int hoveredCpu = -1;

        private ToolTip cpuTips;

        private int CellWpx
        {
            get
            {
                return Theme.S(30);
            }
        }

        private int CellHpx
        {
            get
            {
                return Theme.S(30);
            }
        }

        public ulong DisabledMask { get; set; }

        public bool ShowDisabledPattern { get; set; }

        internal Func<int, string> CpuHint { get; set; }

        public bool SingleSelection { get; set; }

        public ulong SchedulingGameMask { get; set; }

        public ulong SchedulingIsolationMask { get; set; }

        public bool SchedulingOverlay { get; set; }

        public Color SelectionColor { get; set; }

        internal static Color GameColor
        {
            get
            {
                return Theme.Accent;
            }
        }

        internal static Color IsolationColor
        {
            get
            {
                return Theme.Accent2;
            }
        }

        public ulong Selected
        {
            get
            {
                return selected;
            }
            set
            {
                ulong valueMask = value & allMask;
                if (valueMask != selected)
                {
                    selected = valueMask;
                    SyncCells();
                    Invalidate();
                }
            }
        }

        internal Rectangle FocusedCellBounds
        {
            get
            {
                foreach (Band band in bands)
                {
                    foreach (Group group in band.Groups)
                    {
                        foreach (Cell cell in group.Cells)
                        {
                            if (cell.Cpu == focusCpu)
                            {
                                return cell.Rect;
                            }
                        }
                    }
                }
                return Rectangle.Empty;
            }
        }

        public bool Editable
        {
            get
            {
                return editable;
            }
            set
            {
                editable = value;
                base.TabStop = value;
                Cursor = (value ? Cursors.Hand : Cursors.Default);
            }
        }

        public event Action<ulong> SelectionChanged;

        internal event Action<Rectangle> FocusedCellChanged;

        internal event Action<int> DisabledCpuClicked;

        public CoreMatrix()
        {
            SetStyle(ControlStyles.UserPaint | ControlStyles.ResizeRedraw | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);
            BackColor = Theme.Bg;
            allMask = CpuTopology.AllMask;
            selected = allMask;
            for (int i = 0; i < 64; i++)
            {
                cellOn[i].Speed = 0.34f;
            }
            SnapCells();
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            UiClock.Frame += OnFrame;
        }

        protected override void OnHandleDestroyed(EventArgs e)
        {
            UiClock.Frame -= OnFrame;
            base.OnHandleDestroyed(e);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && cpuTips != null)
            {
                cpuTips.Dispose();
                cpuTips = null;
            }
            base.Dispose(disposing);
        }

        private void OnFrame(object s, EventArgs e)
        {
            bool animationChanged = false;
            for (int i = 0; i < 64; i++)
            {
                if (cellOn[i].Step())
                {
                    animationChanged = true;
                }
            }
            if (animationChanged)
            {
                Invalidate();
            }
        }

        private void SnapCells()
        {
            for (int i = 0; i < 64; i++)
            {
                cellOn[i].Set(((selected & (ulong)(1L << i)) != 0) ? 1f : 0f);
            }
        }

        private void SyncCells()
        {
            if (!base.IsHandleCreated)
            {
                SnapCells();
                return;
            }
            for (int i = 0; i < 64; i++)
            {
                cellOn[i].To(((selected & (ulong)(1L << i)) != 0) ? 1f : 0f);
            }
            UiClock.Wake();
        }

        internal void ShowSelectionImmediately(ulong mask)
        {
            selected = mask & allMask;
            if (SingleSelection && selected != 0) focusCpu = LowestIndex(selected);
            SnapCells();
            Invalidate();
        }

        internal void ToggleSelection(ulong mask)
        {
            if (!Editable || !base.Enabled)
            {
                return;
            }
            mask &= allMask & (~DisabledMask | Selected);
            if (mask != 0)
            {
                if (SingleSelection)
                {
                    mask &= ~DisabledMask;
                    if (mask == 0) return;
                    Selected = mask & (~mask + 1);
                }
                else Selected = (((Selected & mask) == mask) ? (Selected & ~mask) : (Selected | (mask & ~DisabledMask)));
                if (this.SelectionChanged != null)
                {
                    this.SelectionChanged(Selected);
                }
            }
        }

        protected override void OnMouseDown(MouseEventArgs e)
        {
            base.OnMouseDown(e);
            if (!Editable || !Enabled || e.Button != MouseButtons.Left)
            {
                return;
            }
            Focus();
            foreach (Band band in bands)
            {
                foreach (Group group in band.Groups)
                {
                    foreach (Cell cell in group.Cells)
                    {
                        if (cell.Rect.Contains(e.Location))
                        {
                            focusCpu = cell.Cpu;
                            SelectCpu(cell.Cpu);
                            return;
                        }
                    }
                    if (group.Rect.Contains(e.Location))
                    {
                        if (DisabledCpuClicked != null && (group.Mask & ~DisabledMask) == 0) SelectCpu(LowestIndex(group.Mask));
                        else ToggleSelection(group.Mask);
                        return;
                    }
                }
            }
        }

        private void SelectCpu(int cpu)
        {
            ulong mask = 1UL << cpu;
            if ((allMask & mask) == 0) return;
            if ((DisabledMask & mask) != 0 && DisabledCpuClicked != null)
            {
                DisabledCpuClicked(cpu);
                return;
            }
            ToggleSelection(mask);
        }

        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);
            int cpu = -1;
            if (CpuHint != null)
            {
                foreach (Band band in bands)
                    foreach (Group group in band.Groups)
                        foreach (Cell cell in group.Cells)
                            if (cell.Rect.Contains(e.Location)) cpu = cell.Cpu;
            }
            if (cpu == hoveredCpu) return;
            hoveredCpu = cpu;
            string hint = cpu < 0 || CpuHint == null ? null : CpuHint(cpu);
            if (string.IsNullOrEmpty(hint))
            {
                if (cpuTips != null) cpuTips.SetToolTip(this, null);
                return;
            }
            if (cpuTips == null)
                cpuTips = new ToolTip { InitialDelay = 400, ReshowDelay = 100, AutoPopDelay = 8000, ShowAlways = true };
            cpuTips.SetToolTip(this, hint);
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            hoveredCpu = -1;
            if (cpuTips != null) cpuTips.SetToolTip(this, null);
        }

        protected override bool IsInputKey(Keys keyData)
        {
            Keys keys = keyData & Keys.KeyCode;
            if (!Editable || (keys != Keys.Left && keys != Keys.Right && keys != Keys.Up && keys != Keys.Down && keys != Keys.Space))
            {
                return base.IsInputKey(keyData);
            }
            return true;
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            base.OnKeyDown(e);
            if (!Editable || !Enabled || e.Modifiers != 0)
            {
                return;
            }
            int focusCpuSnapshot = focusCpu;
            if (e.KeyCode == Keys.Space)
            {
                SelectCpu(focusCpu);
            }
            else
            {
                if (e.KeyCode != Keys.Left && e.KeyCode != Keys.Up && e.KeyCode != Keys.Right && e.KeyCode != Keys.Down)
                {
                    return;
                }
                int onKeyDownValue = ((e.KeyCode != Keys.Left && e.KeyCode != Keys.Up) ? 1 : (-1));
                for (int i = 0; i < 64; i++)
                {
                    focusCpu = (focusCpu + onKeyDownValue + 64) % 64;
                    if ((allMask & ~DisabledMask & (ulong)(1L << focusCpu)) != 0)
                    {
                        break;
                    }
                }
            }
            bool handled = (e.SuppressKeyPress = true);
            e.Handled = handled;
            if (focusCpu != focusCpuSnapshot && this.FocusedCellChanged != null)
            {
                this.FocusedCellChanged(FocusedCellBounds);
            }
            Invalidate();
        }

        protected override void OnGotFocus(EventArgs e)
        {
            base.OnGotFocus(e);
            Invalidate();
        }

        protected override void OnLostFocus(EventArgs e)
        {
            base.OnLostFocus(e);
            Invalidate();
        }

        private void DrawInputFocus(Graphics g)
        {
            if (!Editable || !Focused)
            {
                return;
            }
            foreach (Band band in bands)
            {
                foreach (Group group in band.Groups)
                {
                    foreach (Cell cell in group.Cells)
                    {
                        if (cell.Cpu == focusCpu)
                        {
                            ControlPaint.DrawFocusRectangle(g, cell.Rect, Theme.Fg, BackColor);
                        }
                    }
                }
            }
        }

        public int LayoutFor(int width)
        {
            return LayoutBands(width);
        }

        private int LayoutBands(int width)
        {
            allMask = CpuTopology.AllMask;
            bands.Clear();
            laidOutFor = width;
            if (CpuTopology.MultiGroup)
            {
                cacheHeavy = 0;
                return AddBand(new List<ulong>(), UnknownCoreTitle(), width, 0);
            }
            bool physicalKnown = TopologyCountsConfirmed;
            ulong[] cores = CpuTopology.PhysicalCoreMasks();
            if (!physicalKnown)
            {
                var logical = new List<ulong>();
                for (int cpu = 0; cpu < 64; cpu++)
                    if ((allMask & (1UL << cpu)) != 0) logical.Add(1UL << cpu);
                cores = logical.ToArray();
            }
            if (cores.Length == 0) return Theme.S(40);
            cacheHeavy = physicalKnown ? CpuTopology.CacheHeavyMask() : 0;
            int y = 0;
            if (physicalKnown && CpuTopology.CoreTypesConfirmed && CpuTopology.Hybrid)
            {
                var performance = new List<ulong>();
                var efficiency = new List<ulong>();
                var unknown = new List<ulong>();
                foreach (ulong physical in cores)
                {
                    ulong core = physical & allMask;
                    if (core == 0) continue;
                    if ((core & CpuTopology.PerfMask) == core && (core & CpuTopology.EffMask) == 0) performance.Add(core);
                    else if ((core & CpuTopology.EffMask) == core && (core & CpuTopology.PerfMask) == 0) efficiency.Add(core);
                    else unknown.Add(core);
                }
                if (performance.Count > 0) y = AddBand(performance, Lang.T("core.band.perf"), width, y);
                if (efficiency.Count > 0) y = AddBand(efficiency, Lang.T("core.band.eff"), width, y == 0 ? 0 : y + Theme.S(16));
                if (unknown.Count > 0) y = AddBand(unknown, UnknownCoreTitle(), width, y == 0 ? 0 : y + Theme.S(16));
                return y;
            }
            ulong[] dies = physicalKnown ? CpuTopology.DieMasks() : new ulong[0];
            if (dies.Length >= 2)
            {
                for (int i = 0; i < dies.Length; i++)
                {
                    var groups = new List<ulong>();
                    foreach (ulong physical in cores)
                    {
                        ulong core = physical & allMask;
                        if (core != 0 && (core & dies[i]) != 0) groups.Add(core);
                    }
                    if (groups.Count == 0) continue;
                    bool cache = cacheHeavy != 0 && (dies[i] & cacheHeavy) != 0;
                    y = AddBand(groups, Lang.F(cache ? "core.band.ccd.cache" : "core.band.ccd", i), width,
                        y == 0 ? 0 : y + Theme.S(16));
                }
                return y;
            }
            var all = new List<ulong>();
            foreach (ulong physical in cores)
                if ((physical & allMask) != 0) all.Add(physical & allMask);
            return AddBand(all, physicalKnown && CpuTopology.CoreTypesConfirmed ? Lang.T("core.band.all") : UnknownCoreTitle(), width, 0);
        }

        internal static bool TopologyCountsConfirmed
        {
            get { return CpuTopology.PhysicalCoreMasks().Length > 0 && !CpuTopology.MultiGroup && CpuTopology.TopologySourcesAgree && !CpuTopology.AllMaskReconciled; }
        }

        private string UnknownCoreTitle()
        {
            if (!ShowCoreTypeStatus) return Lang.T("core.band.all");
            return PerformancePolicy.Text("处理器核心 · 类型未确认", "CPU cores · type unconfirmed");
        }

        private int AddBand(List<ulong> groups, string title, int width, int y)
        {
            bool smt = false;
            foreach (ulong group in groups)
            {
                if (CpuTopology.CountSetBits(group) > 1)
                {
                    smt = true;
                    break;
                }
            }
            return AddBand(groups, title, width, y, smt);
        }

        private int AddBand(List<ulong> groups, string title, int width, int y, bool smt)
        {
            int addBandValue = 0;
            foreach (ulong group3 in groups)
            {
                addBandValue += CpuTopology.CountSetBits(group3);
            }
            Band band = new Band();
            band.Title = title;
            band.Meta = TopologyCountsConfirmed ? Lang.F(smt ? "core.band.meta.smt" : "core.band.meta.solo", groups.Count, addBandValue)
                : CpuTopology.MultiGroup ? PerformancePolicy.Text("多处理器组 · 核心范围与物理核数未确认", "Multiple processor groups · CPU range and physical core count unconfirmed")
                : addBandValue + PerformancePolicy.Text(" 逻辑核 · 物理核数未确认", " logical CPUs · physical core count unconfirmed");
            band.TitleY = y;
            Band band2 = band;
            y += Theme.S(26);
            int addBandValue2 = 0;
            int addBandValue3 = Theme.S(15) + CellHpx + Theme.S(3) * 2;
            int addBandValue4 = addBandValue3;
            foreach (ulong group4 in groups)
            {
                int countSetBitsResult = CpuTopology.CountSetBits(group4);
                int addBandValue5 = countSetBitsResult * CellWpx + Theme.S(3) * 2;
                if (addBandValue2 > 0 && addBandValue2 + addBandValue5 > width)
                {
                    addBandValue2 = 0;
                    y += addBandValue4 + Theme.S(7);
                }
                Group group = new Group();
                group.Index = LowestIndex(group4);
                group.Mask = group4;
                group.Rect = new Rectangle(addBandValue2, y, addBandValue5, addBandValue3);
                Group group2 = group;
                int addBandValue2Offset = addBandValue2 + Theme.S(3);
                bool firstSibling = true;
                for (int i = 0; i < 64; i++)
                {
                    if ((group4 & (ulong)(1L << i)) != 0)
                    {
                        group2.Cells.Add(new Cell
                        {
                            Cpu = i,
                            Rect = new Rectangle(addBandValue2Offset, y + Theme.S(15) + Theme.S(3), CellWpx, CellHpx),
                            Sibling = !firstSibling
                        });
                        addBandValue2Offset += CellWpx;
                        firstSibling = false;
                    }
                }
                band2.Groups.Add(group2);
                addBandValue2 += addBandValue5 + Theme.S(7);
            }
            bands.Add(band2);
            return y + addBandValue4;
        }

        private static int LowestIndex(ulong mask)
        {
            for (int i = 0; i < 64; i++)
            {
                if ((mask & (ulong)(1L << i)) != 0)
                {
                    return i;
                }
            }
            return 0;
        }

        protected override void OnResize(EventArgs e)
        {
            base.OnResize(e);
            if (base.Width > 0 && base.Width != laidOutFor)
            {
                LayoutFor(base.Width);
                Invalidate();
            }
        }

        internal static HeadTag HeadTagFor(bool exclusive, bool anyOn, bool cache, bool multiThread)
        {
            if (exclusive)
            {
                return HeadTag.Exclusive;
            }
            if (anyOn)
            {
                return HeadTag.Primary;
            }
            if (cache)
            {
                return HeadTag.Cache;
            }
            if (!multiThread)
            {
                return HeadTag.None;
            }
            return HeadTag.Smt;
        }

        internal static bool HeadTagFits(int headWidth, int indexWidth, int tagWidth, int gap)
        {
            if (tagWidth > 0)
            {
                return indexWidth + gap + tagWidth <= headWidth;
            }
            return false;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics graphics = e.Graphics;
            if (Backdrop.AppliesTo(this))
            {
                Backdrop.PaintOnCard(graphics, this, base.ClientRectangle);
            }
            else
            {
                using (SolidBrush brush = new SolidBrush(BackColor))
                {
                    graphics.FillRectangle(brush, base.ClientRectangle);
                }
            }
            graphics.SmoothingMode = SmoothingMode.AntiAlias;
            foreach (Band band in bands)
            {
                Rectangle bounds = new Rectangle(0, band.TitleY, base.Width, Theme.S(26));
                TextRenderer.DrawText(graphics, band.Title, Theme.UI(8.4f, true), bounds, Theme.Fg, TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                TextRenderer.DrawText(graphics, band.Meta, Theme.MonoFor(band.Meta, 7.4f), bounds, Theme.Faint, TextFormatFlags.Right | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
                int top = band.TitleY + Theme.S(26) - Theme.S(4);
                using (Pen pen = new Pen(Theme.Stroke))
                {
                    graphics.DrawLine(pen, 0, top, base.Width - 1, top);
                }
                foreach (Group group in band.Groups)
                {
                    DrawGroup(graphics, group);
                }
            }
            DrawInputFocus(graphics);
        }

        private void DrawGroup(Graphics g, Group grp)
        {
            int processedCount = 0;
            foreach (Cell cell in grp.Cells)
            {
                if ((selected & (ulong)(1L << cell.Cpu)) != 0)
                {
                    processedCount++;
                }
            }
            bool hasSelectedThreads = processedCount > 0;
            bool exclusiveSibling = MarkExclusive && grp.Cells.Count > 1 && processedCount == 1;
            float measuredValue = 0f;
            foreach (Cell cell2 in grp.Cells)
            {
                if (cellOn[cell2.Cpu].Value > measuredValue)
                {
                    measuredValue = cellOn[cell2.Cpu].Value;
                }
            }
            Rectangle rect = grp.Rect;
            rect.Width--;
            rect.Height--;
            using (GraphicsPath path = Theme.TechPath(rect, Theme.S(5)))
            {
                using (SolidBrush brush = new SolidBrush(Col.Lerp(Theme.Bg, Theme.Card, measuredValue)))
                {
                    g.FillPath(brush, path);
                }
                Color color = (exclusiveSibling ? Col.Alpha(Theme.Accent, 200) : (hasSelectedThreads ? Theme.StrokeHi : Theme.Stroke));
                float lowerBound = (exclusiveSibling ? Math.Max(1f, (float)Theme.S(2) * 0.75f) : 1f);
                using (Pen pen = new Pen(color, lowerBound))
                {
                    g.DrawPath(pen, path);
                }
            }
            Rectangle bounds = new Rectangle(rect.Left + Theme.S(3), rect.Top + Theme.S(1), rect.Width - Theme.S(3) * 2, Theme.S(15));
            bool cacheHeavyGroup = cacheHeavy != 0 && (grp.Mask & cacheHeavy) != 0;
            TextRenderer.DrawText(g, (TopologyCountsConfirmed ? "C" : "L") + grp.Index.ToString("00"), Theme.Mono(6.9f), bounds, (!cacheHeavyGroup) ? (hasSelectedThreads ? Theme.Dim : Theme.Faint) : (hasSelectedThreads ? Theme.Accent2 : Col.Alpha(Theme.Accent2, 170)), TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            bool multiThread = grp.Cells.Count > 1;
            string coreTagExclusiveText;
            switch (HeadTagFor(exclusiveSibling, hasSelectedThreads, cacheHeavyGroup, multiThread))
            {
            case HeadTag.Exclusive:
                coreTagExclusiveText = Lang.T("core.tag.exclusive");
                break;
            case HeadTag.Primary:
                coreTagExclusiveText = PrimaryTag;
                break;
            case HeadTag.Cache:
                coreTagExclusiveText = Lang.T("core.tag.cache");
                break;
            case HeadTag.Smt:
                coreTagExclusiveText = "SMT";
                break;
            default:
                coreTagExclusiveText = null;
                break;
            }
            if (coreTagExclusiveText != null)
            {
                Font font = Theme.MonoFor(coreTagExclusiveText, 6.4f);
                int indexWidth = TextRenderer.MeasureText(g, (TopologyCountsConfirmed ? "C" : "L") + grp.Index.ToString("00"), Theme.Mono(6.9f), bounds.Size, TextFormatFlags.NoPadding).Width;
                int tagWidth = TextRenderer.MeasureText(g, coreTagExclusiveText, font, bounds.Size, TextFormatFlags.NoPadding).Width;
                if (!HeadTagFits(bounds.Width, indexWidth, tagWidth, Theme.S(3)))
                {
                    coreTagExclusiveText = null;
                }
            }
            if (coreTagExclusiveText != null)
            {
                TextRenderer.DrawText(g, coreTagExclusiveText, Theme.MonoFor(coreTagExclusiveText, 6.4f), bounds, exclusiveSibling ? Theme.Accent : (hasSelectedThreads ? Col.Alpha(Theme.Accent, 220) : (cacheHeavyGroup ? Col.Alpha(Theme.Accent2, 170) : Col.Alpha(Theme.Faint, 150))), TextFormatFlags.Right | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            }
            foreach (Cell cell3 in grp.Cells)
            {
                DrawCell(g, cell3);
            }
        }

        private void DrawCell(Graphics g, Cell c)
        {
            float value = cellOn[c.Cpu].Value;
            Rectangle rect = c.Rect;
            rect.Inflate(-Theme.S(2), -Theme.S(2));
            Color color = ((SchedulingOverlay && !SelectionColor.IsEmpty) ? SelectionColor : Theme.Accent);
            Color color2 = Col.Lerp(Theme.Bg, color, value);
            bool disabled = (DisabledMask & (ulong)(1L << c.Cpu)) != 0 || !base.Enabled;
            if (disabled)
            {
                color2 = Theme.Card;
            }
            using (GraphicsPath path = Theme.TechPath(rect, Theme.S(4)))
            {
                using (SolidBrush brush = new SolidBrush(color2))
                {
                    g.FillPath(brush, path);
                }
                if (disabled && ShowDisabledPattern)
                {
                    // 编号区域保持纯色，避免禁用纹理遮挡文字。
                    Size textSize = TextRenderer.MeasureText(g, c.Cpu.ToString(), Theme.Mono(7.6f), rect.Size, TextFormatFlags.NoPadding);
                    var number = new Rectangle(rect.Left + (rect.Width - textSize.Width) / 2 - Theme.S(1),
                        rect.Top + (rect.Height - textSize.Height) / 2 - Theme.S(1),
                        textSize.Width + Theme.S(2), textSize.Height + Theme.S(2));
                    using (var pattern = new Region(path))
                    using (var brush = new HatchBrush(HatchStyle.ForwardDiagonal, Col.Alpha(Theme.Faint, 65), Color.Transparent))
                    {
                        pattern.Exclude(number);
                        g.FillRegion(brush, pattern);
                    }
                }
                Color color3 = Col.Lerp(Theme.Stroke, Col.Alpha(color, 235), value);
                using (Pen pen = new Pen(color3, 1f))
                {
                    g.DrawPath(pen, path);
                }
            }
            TextRenderer.DrawText(g, c.Cpu.ToString(), Theme.Mono(7.6f), rect, disabled ? Theme.Faint : Col.Lerp(Theme.Dim, Theme.OnAccent, value), TextFormatFlags.HorizontalCenter | TextFormatFlags.SingleLine | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPadding);
            if (!SchedulingOverlay)
            {
                return;
            }
            ulong cpuOffset = (ulong)(1L << c.Cpu);
            int left = rect.Left + Theme.S(3);
            int top = rect.Bottom - Theme.S(4);
            ulong[] numericValueItems = new ulong[2] { SchedulingGameMask, SchedulingIsolationMask };
            Color[] colorItems = new Color[2] { GameColor, IsolationColor };
            for (int i = 0; i < numericValueItems.Length; i++)
            {
                if ((numericValueItems[i] & cpuOffset) != 0)
                {
                    using (SolidBrush brush2 = new SolidBrush(colorItems[i]))
                    {
                        g.FillRectangle(brush2, left, top, Theme.S(5), Theme.S(2));
                    }
                }
                left += Theme.S(7);
            }
        }
    }
}
