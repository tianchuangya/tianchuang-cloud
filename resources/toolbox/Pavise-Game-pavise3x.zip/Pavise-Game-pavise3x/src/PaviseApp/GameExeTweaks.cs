using System;
using Microsoft.Win32;

namespace PaviseApp
{
    internal static class GameExeTweaks
    {
        private const string GpuKey = "SOFTWARE\\Microsoft\\DirectX\\UserGpuPreferences";

        internal static string ReadField(string current, string field)
        {
            return PrefFieldText.ReadField(current, field);
        }

        public static bool PrefersIntegrated(string exePath)
        {
            if (string.IsNullOrEmpty(exePath))
            {
                return false;
            }
            try
            {
                using (RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\DirectX\\UserGpuPreferences"))
                {
                    if (registryKey == null)
                    {
                        return false;
                    }
                    return string.Equals(ReadField(registryKey.GetValue(exePath) as string, "GpuPreference"), "1", StringComparison.Ordinal);
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
